package om.example.demo.menu;

import org.springframework.data.repository.CrudRepository;



public interface MenuRepo extends CrudRepository<Menu, Integer>{

}
